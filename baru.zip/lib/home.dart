import 'package:flutter/material.dart';
import 'package:study_mate/auth.dart';
import 'package:study_mate/main.dart';
import 'package:study_mate/signin.dart';
import 'package:study_mate/tampilanProfil.dart';
import 'package:study_mate/tampilanRekomendasi.dart';
import 'package:study_mate/tampilanRiwayat.dart';

class MyAppState extends StatefulWidget {
  const MyAppState({Key? key}) : super(key: key);

  // const MyAppState({Key? key}) : super(key: key);

  @override
  State<MyAppState> createState() => _MyAppStateState();
}

class _MyAppStateState extends State<MyAppState> {
  List<Widget> _items = [
    tampilan1(),
    tampilan2(),
    tampilan3(),
  ];
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Card Carousel App',
      theme: ThemeData(
          // primarySwatch: Colors.blue,
          ),
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xFFEAEAF0),
          leading: IconButton(
            icon: Icon(
              Icons.home,
              size: 40.0,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => MyAppState()));
            },
          ),
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.message, size: 40.0, color: Colors.black),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => MyAppState()));
              },
            ),
            PopupMenuButton(
              itemBuilder: (BuildContext context) {
                return [
                  PopupMenuItem(
                    child: InkWell(
                    onTap: () => {
                      AuthService().signOut(),
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => MyApp())),
                    },
                    child: Row(
                      children: <Widget>[
                        Icon(Icons.logout, color: Colors.black),
                        Text("Logout")
                      ],
                    ),
                  ))
                ];
              },
              icon: Icon(Icons.more_vert, size: 40.0, color: Colors.black),
            )
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.recommend),
              label: 'Rekomendasi',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.history_edu),
              label: 'Riwayat',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.account_circle),
              label: 'Profile',
            ),
          ],
          currentIndex: _selectedIndex,
          selectedItemColor: Colors.green,
          unselectedItemColor: Colors.grey,
          onTap: _onTap,
        ),
        body: Container(
          decoration: const BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("img/BG.jpg"), fit: BoxFit.cover)),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                IndexedStack(index: _selectedIndex, children: _items),
                Container(
                  height: 30,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _onTap(int index) {
    _selectedIndex = index;
    setState(() {});
  }
}

class home extends StatelessWidget {
  const home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'DAPA TRANSPORT',
        theme: ThemeData(
            // primarySwatch: Colors.blue,
            ),
        home: menuHome());
  }
}

class menuHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage("img/BG.jpg"), fit: BoxFit.cover)),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Container(
                alignment: Alignment.topLeft,
                child: Image.asset(
                  "img/dapa.png",
                  height: 150,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

void clicked(BuildContext context, menu) {
  final scaffold = Scaffold.of(context);
  scaffold.showSnackBar(
    SnackBar(
      content: Text(menu),
      action: SnackBarAction(
          label: 'UNDO', onPressed: scaffold.hideCurrentSnackBar),
    ),
  );
}
