import 'package:flutter/material.dart';

class tampilan3 extends StatelessWidget {
  const tampilan3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
          color: Colors.white,
          image: DecorationImage(
              image: AssetImage("img/BG.jpg"), fit: BoxFit.cover)),
      child: Center(
        child: Column(
          children: [
            Container(
              child: Icon(
                Icons.account_circle,
                size: 200,
              ),
            ),
            Text(
              "Ketut Dendi Udrayana",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 28),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
              padding: EdgeInsets.all(10),
              width: double.infinity,
              // color: Colors.white,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black,
                    // spreadRadius: 5,
                    offset: Offset(-3, -3), // changes position of shadow
                  ),
                ],
              ),
              child: Column(
                // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: EdgeInsets.only(left: 40, right: 40),
                    child: Container(
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Column(
                          children: [
                            Text(
                              "Alamat: ",
                            ),
                            Container(
                              height: 20,
                            ),
                            Container(
                              height: 1,
                              width: double.infinity,
                              color: Colors.black,
                            ),
                            Container(
                              height: 10,
                            ),
                            Text("Nomor HP :"),
                            Container(
                              height: 180,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
