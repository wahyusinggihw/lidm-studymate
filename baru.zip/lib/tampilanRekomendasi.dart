import 'package:flutter/material.dart';

import 'package:study_mate/kendaraan.dart';

class tampilan1 extends StatefulWidget {
  const tampilan1({Key? key}) : super(key: key);

  @override
  State<tampilan1> createState() => _tampilan1State();
}

class _tampilan1State extends State<tampilan1> {
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage("img/BG.jpg"), fit: BoxFit.cover),
        ),
      ),
      Container(
        alignment: Alignment.topLeft,
        child: Image.asset(
          "img/dapa.png",
          height: 150,
        ),
      ),
      Container(
        padding: EdgeInsets.fromLTRB(25, 0, 25, 25),
        child: Row(
          children: [
            Container(
              height: 185,
              width: 160,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    child: Image.asset(
                      "img/motor.png",
                      height: 100,
                    ),
                    padding: const EdgeInsets.all(12),
                  ),
                  Container(
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ListMobil()));
                      },
                      child: Text(
                        "MOTOR",
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(255, 7, 7, 7),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(20),
            ),
            Container(
              height: 185,
              width: 160,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    child: Image.asset(
                      "img/mobil.png",
                      height: 100,
                    ),
                    padding: const EdgeInsets.all(12),
                  ),
                  Container(
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ListMobil()));
                      },
                      child: Text(
                        "MOBIL",
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(255, 7, 7, 7),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
      Container(
        padding: EdgeInsets.all(25),
        child: Row(
          children: [
            Container(
              height: 185,
              width: 160,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    child: Image.asset(
                      "img/busl.png",
                      height: 100,
                    ),
                    padding: const EdgeInsets.all(12),
                  ),
                  Container(
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ListMobil()));
                      },
                      child: Text(
                        "BUS",
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(255, 7, 7, 7),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(20),
            ),
            Container(
              height: 185,
              width: 160,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    child: Image.asset(
                      "img/mobil.png",
                      height: 100,
                    ),
                    padding: const EdgeInsets.all(12),
                  ),
                  Container(
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ListMobil()));
                      },
                      child: Text(
                        "SEPEDA",
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(255, 7, 7, 7),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    ]);
  }
}
