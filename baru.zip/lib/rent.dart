import 'package:flutter/material.dart';
import 'home.dart';
import 'kendaraan.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'tampilanRiwayat.dart';

class Rent extends StatefulWidget {
  Rent({Key? key}) : super(key: key);

  @override
  State<Rent> createState() => _RentState();
}

class _RentState extends State<Rent> {
  final TextEditingController _namaController = TextEditingController();
  final TextEditingController _noktpController = TextEditingController();
  final TextEditingController _hariController = TextEditingController();

  final CollectionReference _booking =
      FirebaseFirestore.instance.collection('booking');
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Color(0xFF696EF6),
        appBar: AppBar(
          backgroundColor: Color(0xFFEAEAF0),
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ListMobil()));
            },
          ),
        ),
        body: SingleChildScrollView(
          child: Container(
            decoration: const BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("img/BG.jpg"), fit: BoxFit.cover)),
            child: Center(
              child: Container(
                margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
                padding: EdgeInsets.all(10),
                width: double.infinity,
                // color: Colors.white,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black,
                      // spreadRadius: 5,
                      offset: Offset(-3, -3), // changes position of shadow
                    ),
                  ],
                ),
                child: Column(
                  // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: EdgeInsets.only(left: 40),
                      height: 200,
                      width: 200,
                      child: RawMaterialButton(
                        onPressed: () {},
                        child: Image.asset("img/mobil.png"),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.only(right: 40),
                      child: Container(
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Column(
                            children: [
                              Text(
                                "Avanza",
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text("Harga Sewa"),
                              Text("Rp.150.000/hari"),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      height: 10,
                    ),
                    TextField(
                      controller: _noktpController,
                      decoration: InputDecoration(
                          contentPadding: EdgeInsets.symmetric(horizontal: 10),
                          hintText: "No KTP"),
                    ),
                    Container(
                      height: 20,
                    ),
                    TextField(
                      controller: _namaController,
                      decoration: InputDecoration(
                          contentPadding: EdgeInsets.symmetric(horizontal: 10),
                          hintText: "Nama"),
                    ),
                    Container(
                      height: 20,
                    ),
                    TextField(
                      controller: _hariController,
                      decoration: InputDecoration(
                          contentPadding: EdgeInsets.symmetric(horizontal: 10),
                          hintText: "Sewa Berapa Hari"),
                    ),
                    Container(
                      height: 20,
                    ),
                    Container(
                      // color: Colors.grey,
                      alignment: Alignment.centerRight,
                      child: ElevatedButton(
                        style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.resolveWith<Color>(
                            (Set<MaterialState> states) {
                              if (states.contains(MaterialState.pressed))
                                return Colors.grey;
                              return Colors
                                  .grey; // Use the component's default.
                            },
                          ),
                        ),
                        child: Text(
                          "Booking!",
                          style: TextStyle(
                            color: Colors.black,
                          ),
                        ),
                        onPressed: () async {
                          final String? nama = _namaController.text;
                          final String? noktp = _noktpController.text;
                          final String? hari = _hariController.text;

                          if(nama != null && noktp != null && hari != null){
                            await _booking.add({
                            'nama': nama,
                            'noktp': noktp,
                            'hari': hari,
                          },);
                          Navigator.push(context, MaterialPageRoute(builder: (context) => tampilan2()));
                        };
                        }, 
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
