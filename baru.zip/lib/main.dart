import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:study_mate/signup.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:study_mate/signin.dart';
import 'firebase_options.dart';

//https://dapa-apps-default-rtdb.firebaseio.com
void main() async {
  await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
  );

  // WidgetsFlutterBinding.ensureInitialized();
  // await Firebase.initializeApp();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DAPA TRANSPORT',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'DAPA TRANSPORT'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage("img/BG.jpg"), fit: BoxFit.cover)),
        child: Center(
          child: Column(
            children: <Widget>[
              Container(
                alignment: Alignment.topLeft,
                child: Image.asset(
                  "img/dapa.png",
                  height: 150,
                ),
              ),
              Container(
                height: 80,
              ),
              Container(
                margin: EdgeInsets.fromLTRB(30, 0, 30, 0),
                padding: EdgeInsets.all(10),

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                //BoxDecoration(borderRadius: BorderRadius.circular(20)),
                child: Column(
                  children: [
                    CarouselSlider(
                      items: [
                        Padding(
                          padding: const EdgeInsets.all(30.0),
                          child: Image.asset(
                            "img/busl.png",
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(30.0),
                          child: Image.asset(
                            "img/mobil.png",
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.all(30.0),
                          child: Image.asset(
                            "img/motor.png",
                          ),
                        )
                      ],
                      //Slider Container properties
                      options: CarouselOptions(
                        autoPlay: true,
                      ),
                    ),
                    const Text(
                      'Selamat Datang di DAPA Transport',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Text(
                      ' ',
                    ),
                    const Text(
                      'Aplikasi yang bikin hidup kamu lebih nyaman. Siap bantuin semua keperluan transport anda selama liburan, kapan pun, dan dimana pun',
                    ),
                    const Text(
                      ' ',
                    ),
                  ],
                ),
              ),
              Container(
                height: 90,
              ),
              Container(
                width: 350,
                height: 40,
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: Color.fromARGB(255, 49, 49, 49),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Signin()));
                  },
                  child: Text(
                    "Masuk",
                    style: TextStyle(
                      color: Color.fromARGB(255, 255, 253, 253),
                    ),
                  ),
                ),
              ),
              Container(
                height: 10,
              ),
              Container(
                width: 350,
                height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black,
                      spreadRadius: 2,
                      offset: Offset(0, 0), // changes position of shadow
                    ),
                  ],
                ),
                child: TextButton(
                  style: TextButton.styleFrom(
                    shadowColor: Colors.black,
                    backgroundColor: Color.fromARGB(255, 255, 255, 255),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Signup()));
                  },
                  child: Text(
                    "Belum punya akun? Daftar dulu",
                    style: TextStyle(
                      color: Color.fromARGB(255, 2, 2, 2),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              Container(
                height: 22,
              ),
              Container(
                width: 410,
                height: 40,
                child: RichText(
                    textAlign: TextAlign.center,
                    text: const TextSpan(children: [
                      TextSpan(
                          text:
                              'Dengan memasukkan atau mendaftar, kamu menyetujui',
                          style: TextStyle(
                            color: Color.fromARGB(255, 2, 2, 2),
                            fontWeight: FontWeight.bold,
                          )),
                      TextSpan(
                          text: ' Ketentuan Layanan ',
                          style: TextStyle(
                            color: Color.fromARGB(255, 255, 255, 255),
                            fontWeight: FontWeight.bold,
                          )),
                      TextSpan(
                          text: 'dan',
                          style: TextStyle(
                            color: Color.fromARGB(255, 2, 2, 2),
                            fontWeight: FontWeight.bold,
                          )),
                      TextSpan(
                          text: ' kebijakan Privasi',
                          style: TextStyle(
                            color: Color.fromARGB(255, 255, 255, 255),
                            fontWeight: FontWeight.bold,
                          )),
                      TextSpan(
                          text: '.',
                          style: TextStyle(
                            color: Color.fromARGB(255, 2, 2, 2),
                            fontWeight: FontWeight.bold,
                          )),
                    ])),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
