import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class achivement extends StatefulWidget {
  const achivement({Key? key}) : super(key: key);

  @override
  State<achivement> createState() => _achivementState();
}

class _achivementState extends State<achivement> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: 150,
        child: Column(
          children: [
            Text('Achivement'),
            
          ],
        )
      ),
    );
  }
}